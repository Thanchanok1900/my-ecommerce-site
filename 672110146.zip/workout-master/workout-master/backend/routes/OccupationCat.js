const express = require('express');
const router = express.Router();

const OccupationCat = require('../../json/occupation-cat.json');
router.get('/', (req , res) => {
    res.json(OccupationCat);

});

module.exports = router;